apk add --no-cache curl
