echo $(( {ARGUMENT} ))
